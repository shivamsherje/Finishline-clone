import React from "react";
import hats from "../Assets/img16.jfif";
const Featured3 = () => {
  return (
    <div style={{ width: "90%", margin: "auto", marginTop: "20px" }}>
      <img style={{ width: "100%", marginTop: "20px" }} src={hats} />
    </div>
  );
};

export default Featured3;
