import React from "react";
import bannner from "../Assets/homepage1.png";
const Banner1 = (props) => {
  return (
    <div style={{width:"90%",margin:"auto"}}>
      <img style={{margin:"auto", width:"100%"}} src={bannner} alt="" />
    </div>
  );
};

export default Banner1;
