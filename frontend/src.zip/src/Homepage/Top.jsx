import React from "react";

import img1 from "../Assets/home1.jpeg";


const Top = () => {
  return (
    <div>
      <img src={img1} />
    </div>
  );
};

export default Top;

