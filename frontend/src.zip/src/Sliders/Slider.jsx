import React from 'react'

export const RecomanedSlider = () => {
    return (
       <div>
        
       </div>
    )
}

