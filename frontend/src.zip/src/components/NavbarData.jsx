export const NavNewArrival = [
    { id: 1, title: "Men's New Arrivals", image: 'https://media.finishline.com/i/finishline/DM0029_001_P1?$default$&w=671&&h=671&bg=rgb(237,237,237)', path: '#' },
    { id: 2, title: "Women's New Arrivals", image: 'https://media.finishline.com/s/finishline/IG9653_624?$Small$&fmt=webp', path: '#' },
    { id: 3, title: "Boys's New Arrivals", image: 'https://finishline.a.bigcontent.io/v1/static/FNL_121522_Nike_Zoom_Freak_4_Kids_Basketball__Basketball_LP_Tile_604x604?fmt=webp', path: '#' },
    { id: 4, title: "Girls's New Arrivals", image: 'https://media.finishline.com/s/finishline/AO2372G_031?$Small$&fmt=webp', path: '#' },
]

export const men = [
    { id: 1, title: "Shoes", path: "#" },
    { id: 1, title: "Clothing", path: "#" },
    { id: 1, title: "Brands", path: "#" },
    { id: 1, title: "Trending Now", path: "#" },
    { id: 2, title: "Basketball", path: "#" },
    { id: 2, title: "Hoodies & Sweatshirts", path: "#" },
    { id: 2, title: "Nike", path: "#" },
    { id: 2, title: "Trending Styles", path: "#" },
    { id: 2, title: "Running", path: "#" },
    { id: 2, title: "Sweatpants & Joggers", path: "#" },
    { id: 2, title: "Jordan", path: "#" },
    { id: 2, title: "Recent Releases", path: "#" },
    { id: 2, title: "Casual", path: "#" },
    { id: 2, title: "Jackets, Coats & Vests", path: "#" },
    { id: 2, title: "adidas", path: "#" },
    { id: 2, title: "Winter Essentials", path: "#" },
    { id: 2, title: "Boots", path: "#" },
    { id: 2, title: "Shirts, Tanks & Graphic Tees", path: "#" },
    { id: 2, title: "New Balance", path: "#" },
    { id: 2, title: "All White Styles", path: "#" },
    { id: 2, title: "Training & Cleats", path: "#" },
    { id: 2, title: "Shorts & Swimwear", path: "#" },
    { id: 2, title: "On", path: "#" },
    { id: 2, title: "Men's Cargo", path: "#" },
    { id: 2, title: "Sandals, Slides & Slippers", path: "#" },
    { id: 2, title: "Matching Sets", path: "#" },
    { id: 2, title: "Timberland", path: "#" },
    { id: 2, title: "New Era Team Gear", path: "#" },
    { id: 2, title: "Sizes 14 - 20", path: "#" },
    { id: 2, title: "2 for $40 Tees & Shorts", path: "#" },
    { id: 2, title: "Converse", path: "#" },
    { id: 2, title: "Nike Tech Fleece Outfits", path: "#" },
    { id: 2, title: "Best Sellers", path: "#" },
    { id: 2, title: "Fan Gear & Jerseys", path: "#" },
    { id: 2, title: "Puma", path: "#" },
    { id: 2, title: "", path: "#" },
    { id: 2, title: "Styles Under $100", path: "#" },
    { id: 2, title: "Socks & Underwear", path: "#" },
    { id: 2, title: "Crocs", path: "#" },
    { id: 2, title: "", path: "#" },
    { id: 2, title: "All Shoes", path: "#" },
    { id: 2, title: "Denim & Jeans", path: "#" },
    { id: 2, title: "The North Face", path: "#" },
    { id: 2, title: "", path: "#" },
    { id: 2, title: "", path: "#" },
    { id: 2, title: "Styles Under $50", path: "#" },
    { id: 2, title: "Birkenstock", path: "#" },
    { id: 2, title: "", path: "#" },
    { id: 2, title: "", path: "#" },
    { id: 2, title: "All Clothing", path: "#" },
    { id: 2, title: "Reebok", path: "#" },
    { id: 2, title: "", path: "#" },

]

















































