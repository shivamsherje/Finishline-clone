export const ADD_PRODUCT = 'add/product'
export const REMOVE_PRODUCT = 'remove/product'
export const CHECKOUT_PRODUCTS = 'checkout/product'