import "./App.css";
// import Brands from "./Brands/Brands";
// import Homepage from "./Homepage/Homepage";
import Newarrivals from "./New Arrivals/Newarrivals";
function App() {
  return (
    <div className="App">
      {/* <Homepage /> */}

      {/* <Brands/> */}
      <Newarrivals/>
    </div>
  );
}

export default App;
