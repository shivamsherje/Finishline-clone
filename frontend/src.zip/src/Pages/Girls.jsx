import React from 'react'

export default function Girls() {
  return (
    <div>Girls</div>
  )
}
