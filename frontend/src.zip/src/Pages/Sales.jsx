import React from 'react'

export default function Sales() {
  return (
    <div>Sales</div>
  )
}
