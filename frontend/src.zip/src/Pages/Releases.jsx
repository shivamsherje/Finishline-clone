import React from 'react'

export default function Releases() {
  return (
    <div>Releases</div>
  )
}
