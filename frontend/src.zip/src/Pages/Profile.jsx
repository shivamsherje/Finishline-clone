import React from 'react'
import './Profile.css'
import { Heading, Button, Text } from '@chakra-ui/react'

import { useNavigate } from 'react-router-dom'

export default function Profile() {
    const navigate = useNavigate()

    const logoutFunc = () => {
        localStorage.setItem("isAuth", false)
        alert("Are You sure to logout")
        navigate('/signin')
        window.location.reload()
    }

    const User = JSON.parse(localStorage.getItem("userLogin"))
    console.log(User)

    return (
        <div className='profile-container'>
            <Heading>Profile</Heading>


            <div>
                <Heading size='md'>HELLO {User.firstname.toUpperCase()} {User.lastname.toUpperCase()}</Heading>
                <Text>{User.email}</Text>
                <Text>Date of birth: {User.dob}</Text>
                <p>You've been with us since 2023</p>
                <Button bg='#5271ff' onClick={logoutFunc}>Logout</Button>
            </div>


        </div>
    )
}
