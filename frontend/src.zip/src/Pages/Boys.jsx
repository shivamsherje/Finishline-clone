import React from 'react'

export default function Boys() {
  return (
    <div>Boys</div>
  )
}
